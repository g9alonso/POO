package calculadora;
public class programa {
    public static void main(String[] args) {
        double d=0,result=0;
        int temp,operacion=0;
        lectura le=new lectura();
        operacion al=new operacion();
        temp=le.tipoOperacion(operacion);
        if(temp==1){
            d=al.algebraica(result);
            System.out.println(d);
        }
        else{
            d=al.trigonometrica(result);
            System.out.println(d);
        }
    }
}