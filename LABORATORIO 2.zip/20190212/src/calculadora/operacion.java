package calculadora;
import java.util.Scanner;
class operacion{
    public static double algebraica(double result){
        Scanner sc=new Scanner (System.in);
        int i;
        Double n1,n2;
        System.out.println("Escriba el primer número");
        n1=sc.nextDouble();
        System.out.println("Escriba el segundo número");
        n2=sc.nextDouble();
        System.out.println("Escriba la operación:\n\n1=Suma    2=Resta    3=Multiplicación    4=División");
        i=sc.nextInt(); 
        switch(i){
            case 1:
                result=n1+n2;
            break;
            case 2:
                result=n1-n2;
            break;
            case 3:
                result=n1*n2;
            break;
            case 4:
                if(n2==0) {
                    System.out.println("No se puede dividir entre cero");
                }
                else {
                    result=n1/n2;
                }
            break;
            default:
                System.out.println("Escriba un número válido");
            break;
        }
        return result;
    }
    public static double trigonometrica(double result){
        Scanner sc=new Scanner (System.in);
        int i;
        Double n1;
        System.out.println("Escriba un número");
        n1=sc.nextDouble();
        System.out.println("Elija la función:\n\n1=Seno    2=Coseno    3=Tangente  4=Cotangente");
        i=sc.nextInt();
        switch(i){
            case 1:
                result=Math.sin(n1);
            break;
            case 2:
                result=Math.cos(n1);
            break;
            case 3:
                result=Math.tan(n1);
            break;
            case 4:
                result=(Math.cos(n1))/(Math.sin(n1));
            break;
        }
        return result;
    }
}