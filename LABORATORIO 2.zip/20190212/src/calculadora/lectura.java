package calculadora;
import java.util.Scanner;
class lectura{
    public static int tipoOperacion(int operacion){
        Scanner sc=new Scanner(System.in);
        System.out.println("Escriba el tipo de operación: 1=Algebráica, 2=Trigonométrica");
        operacion=sc.nextInt();
        return operacion;
    }
}